self.assetsManifest = {
  "version": "i3k52it6",
  "assets": [
    {
      "hash": "sha256-47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
      "url": ".nojekyll"
    },
    {
      "hash": "sha256-Ssy1fwwcstBqGm0GdzHG0YRp7FakmEfCI1MyiZIKZCg=",
      "url": "BrothersEnglishApp.styles.css"
    },
    {
      "hash": "sha256-XWJaBINDfSYw2P+24TudQ90/ATMrQLP+sRIjLHu4DiY=",
      "url": "_framework/BrothersEnglishApp.p9c9kevdu9.wasm"
    },
    {
      "hash": "sha256-agZ1Nn6RNEAaRAp4StK4Y5Ucvl7tzvTCBCdIygMBL6U=",
      "url": "_framework/Microsoft.AspNetCore.Components.6h8irc60yi.wasm"
    },
    {
      "hash": "sha256-hBbTf4RRneiRGaGUYmKgYAwNcrHX64qhc/9s98ePgDc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.4izzzykpbr.wasm"
    },
    {
      "hash": "sha256-yEdwMxHr8Gu9RF9vxVwouT+Iy1Gy+tBBqXavjFVKYuY=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.0e44x6vxuq.wasm"
    },
    {
      "hash": "sha256-EScOvyLYbGHyXzhFvrjRm2JZrZ6rIDhmUXRvPgDTopY=",
      "url": "_framework/Microsoft.Extensions.Configuration.33kpvunugc.wasm"
    },
    {
      "hash": "sha256-if+LK/X2QiubYZTpryZvRrMyTu2U2TFOuAkbwh3zGOA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vydvg25cgq.wasm"
    },
    {
      "hash": "sha256-I9RchUtUIR389BC9FoYb+kicxmt1RhJha7WRlbfEbBQ=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.dsinhvif0g.wasm"
    },
    {
      "hash": "sha256-o3DZ22g4zto3RmLtosapeKSFHJzL3VXoNJfcMmtGWGk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.3snpc8ocur.wasm"
    },
    {
      "hash": "sha256-CeqVKkWcaKxrXDPq+OZbCfGsRQfIt+0L4dhwk7GLG9o=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.p8lyq8docm.wasm"
    },
    {
      "hash": "sha256-r3ALIvSOk0g4dgtBLA1dskSc4tr0FbV4GBi9KLaLyhQ=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3z07kbhr47.wasm"
    },
    {
      "hash": "sha256-2o41anbTbxpSDCdgiXgltHqZusjWuT1+M9amuIjDsAM=",
      "url": "_framework/Microsoft.Extensions.Logging.efb40z18hz.wasm"
    },
    {
      "hash": "sha256-ZWvLi4uD1DhpugB3wdKLcFn2yjTRZKmZhg7SRHhNgxE=",
      "url": "_framework/Microsoft.Extensions.Options.hpxn5zhjfy.wasm"
    },
    {
      "hash": "sha256-kHdBFA5OWOMEPY2Az5SW/Fua4Wmqv8F6pKmiIpg6VSE=",
      "url": "_framework/Microsoft.Extensions.Primitives.cpcl4kfg57.wasm"
    },
    {
      "hash": "sha256-6+0tgg2+RDqGeZs+C+BS0ebJpalDt03R+3DlgLaBMcY=",
      "url": "_framework/Microsoft.JSInterop.1hv38i0bi5.wasm"
    },
    {
      "hash": "sha256-FTVJx7gilBV/VWu+ibz7K8ueo7JUXPGj94aH0rf2FXQ=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.58jjh3bwur.wasm"
    },
    {
      "hash": "sha256-of5nF52eB0n8Gth40k9tMRLWfACvbhVSMXF4DZrbdeY=",
      "url": "_framework/System.Collections.Concurrent.7eitjvv1x8.wasm"
    },
    {
      "hash": "sha256-Xz4kj3xwXjm8nQhuad6qEwUuOfC0U/VOuxzGlfE+cno=",
      "url": "_framework/System.Collections.Immutable.hk8h03d39u.wasm"
    },
    {
      "hash": "sha256-STD37/tfd3GNq/hzoIdjvZf2fF1EdcQxmsIk/Zl9ucM=",
      "url": "_framework/System.Collections.vqfg4ajk1k.wasm"
    },
    {
      "hash": "sha256-BtzhKwNiE4/n8KQl+Q8pjvp3tXD5G332yTw7LLVsiSM=",
      "url": "_framework/System.ComponentModel.i6tp01y0dx.wasm"
    },
    {
      "hash": "sha256-FZkYqkuZGJSDu58gCVZOV6vLQQSgMW7WmOyyOpnW4yE=",
      "url": "_framework/System.Console.nhrjdej48y.wasm"
    },
    {
      "hash": "sha256-+rc/Kf48EqfOKwSI682rEo2m2BPiq1MgBwS8Sx2jsAo=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.mk67nx942r.wasm"
    },
    {
      "hash": "sha256-wCAJsY8WvZZLTXO26iAFWH6+l6Wy5eDKp2HiRTjdnXA=",
      "url": "_framework/System.IO.Pipelines.8apfz8l6e2.wasm"
    },
    {
      "hash": "sha256-sSYSw2Q3ePgKFB1IAmNT5Mjv3sAGWYw8K7CviFXFDIU=",
      "url": "_framework/System.Linq.pav9s9skfv.wasm"
    },
    {
      "hash": "sha256-liLmalf4FMdU0aN3On/lCE1vouc0qKQz5SyBIyr4Hdw=",
      "url": "_framework/System.Memory.i1qjgquilc.wasm"
    },
    {
      "hash": "sha256-VXtXfZ5tZZ0XYqFMGkoh5QRY+6NF4MRcxlnwui/HKhk=",
      "url": "_framework/System.Net.Http.Json.5oneox1fi0.wasm"
    },
    {
      "hash": "sha256-6a5E/FHL5QmtjE1Vnn5Au4OGeEs1vymvv15GoIMaAcg=",
      "url": "_framework/System.Net.Http.jxitgbf9x9.wasm"
    },
    {
      "hash": "sha256-2s+SJcHDi0cOPMBhw1X8K3eZgqBhvFv6ZUxDf9BONls=",
      "url": "_framework/System.Net.Primitives.2az562gmti.wasm"
    },
    {
      "hash": "sha256-NG19u4wyFYDP2wc79y/RUuZQtyZcVVoKREjefbxjme0=",
      "url": "_framework/System.Private.CoreLib.wbm37ylymr.wasm"
    },
    {
      "hash": "sha256-x08iu083vpMiQc68cf8c6LhCh4I1M4DwewWUnOGz0KM=",
      "url": "_framework/System.Private.Uri.br763cpnt1.wasm"
    },
    {
      "hash": "sha256-Jr2L5GjxUYLiIlOE41CoRQKYHc4xB13loY9XH9Dmr7I=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.26w8i3zyp9.wasm"
    },
    {
      "hash": "sha256-s1GUiGpz/k0djcThKoodCewMryEFiQB2y9sh1QgOl3Y=",
      "url": "_framework/System.Runtime.fpqa4iej5g.wasm"
    },
    {
      "hash": "sha256-j5zcQYBOuEDBHJgiX4Pngv/z0Tr2d1zjv2bqI2vmJaY=",
      "url": "_framework/System.Security.Cryptography.9u7v6xghh0.wasm"
    },
    {
      "hash": "sha256-qBPVDc1kgRfmJL91yLjXWBOxH02l5xPs2pIs8WxPKCY=",
      "url": "_framework/System.Text.Encodings.Web.wuclkx00gv.wasm"
    },
    {
      "hash": "sha256-tVyC8LUleYSl2PWeKc0kOfFWSySEraHURlZ/uQevxJU=",
      "url": "_framework/System.Text.Json.frzh4gtlsl.wasm"
    },
    {
      "hash": "sha256-AMrBqlWFdE1dRUn8R0gWgRQ/KajPiDGcBqs15ydvmFQ=",
      "url": "_framework/System.Text.RegularExpressions.47o665pipr.wasm"
    },
    {
      "hash": "sha256-+vZdDIIq5QBkrKx4v3nfEA6pLBve2aX5W+tOBYjylf4=",
      "url": "_framework/System.Threading.mx0lfsuvzl.wasm"
    },
    {
      "hash": "sha256-3lCWrko3zwspV40aQhs2S/IMkRSarnHRKIdkHhuXIBA=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-rvIbiK/dhhh1/Id8Fq8ys5BYY1A32lvg5QoyZnO1xk4=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-YiMHfy4JBXeinlyXDXfJnjWZTIn+97lna2GLHs2/OnE=",
      "url": "_framework/dotnet.native.2zf7oibdax.js"
    },
    {
      "hash": "sha256-NoKdQz40uyYJEd2I8WvLVG3JtJnpkMALGSvCZUuSIYI=",
      "url": "_framework/dotnet.native.ipm9j93beu.wasm"
    },
    {
      "hash": "sha256-j86bNQPKznxC4epcftZFbThfaMXvIRmSeHo8PdvTrdA=",
      "url": "_framework/dotnet.runtime.f4b1oiwlzh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-QNUoH3J3MpKGusY3eodiWG1Q1Y3md4F65ALfKnGA348=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-P7ju/reqjF3Ri5H11hi8FXHLEeeMYQzvUhkX0TA58zw=",
      "url": "data/master_sentences.json"
    },
    {
      "hash": "sha256-IeB/ofTnDd7TXEjt3HGVqAfez14nRA8nfKBWLCwNREQ=",
      "url": "data/master_words.json"
    },
    {
      "hash": "sha256-LMg8bxjfOfXJRIQi3ufOpPHYU7pZhh6rLJmT4InndpI=",
      "url": "data/quiz-buzzer.mp3"
    },
    {
      "hash": "sha256-QYjrTNbb2tWbcL1o/rIkIgIwGiTJQzCK8WgkWE24jLM=",
      "url": "data/quiz-dingdong.mp3"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-2ez6ZRHJBeG1lD4pRSOQOTHAzlPGM1EgXaoHVGqPqQc=",
      "url": "index.html"
    },
    {
      "hash": "sha256-tfzvUCF6gCSAM/ovR2KASbZK6KR4AvRYaDlVcZFFPvc=",
      "url": "js/app.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-BbhsOn/vDfWHT9hWxoPsCcsX3O6rNtoGHr0WZ3lv6nk=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-tcmoPa8qNE+UJ1xb1AsmPmkzZYxT9wBz2GiaFVrE+X4=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-r2M7+iwmenszH8XuInuaCzEXQiS3djY/gEHGmYAsREg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-UZeUSOhXCgquRGKz4mk+6FCaIBm7hHCbo6Ypkxf5LMI=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-VrtBtGOVND/Q4EM7dbyqVLpMOEloQA60kbKE1RUiAr4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-HNj9Lv8v7noz1p0ZJvzf/LKZG4YzEDOqPIPwirL0vK8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-cOnSFSyUXXmR9MEzyLwPodOe46YipzaiuUaboSlQnJg=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Nch2KoFhcOw/774lzVhPgh7O9gk3ryIsc/il7pR2hfA=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-mrUeAvhmT4HtAnDbtwaRRZIaYj8viXH2eURJeFyLsoQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-EOa0V69tZcnBGsyuPIz9HDG7t0YcjaiyS8IV8B07gPc=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-U0eEvPb7PXQ8kzNxHPMZKH2B8ovIDd0KmACpxGsC0Qw=",
      "url": "manifest.webmanifest"
    }
  ]
};
